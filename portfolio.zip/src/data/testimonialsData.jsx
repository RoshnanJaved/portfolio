import img1 from "../assets/imgs/people/4-1.jpg";

import Img2 from "../assets/svgs/svgexport-9.svg";
import Img3 from "../assets/svgs/svgexport-10.svg";
import Img4 from "../assets/svgs/svgexport-11.svg";


const TestimonialsData = [
  {
    img: img1,
    name: "Mike Anderson",
    position:"Vivaco Studio",
    para:"I rarely like to write reviews, but the Marketify team truly deserve a standing ovation for their customer support, customisation and most importantly, friendliness and professionalism. Many thanks once again for everything and hope that I get to deal with you again in the near future. "
  },
  {
    img: img1,
    name: "Mike Anderson",
    position:"Vivaco Studio",
    para:"I rarely like to write reviews, but the Marketify team truly deserve a standing ovation for their customer support, customisation and most importantly, friendliness and professionalism. Many thanks once again for everything and hope that I get to deal with you again in the near future. "
  },
  {
    img: img1,
    name: "Mike Anderson",
    position:"Vivaco Studio",
    para:"I rarely like to write reviews, but the Marketify team truly deserve a standing ovation for their customer support, customisation and most importantly, friendliness and professionalism. Many thanks once again for everything and hope that I get to deal with you again in the near future. "
  },
  
];

export default TestimonialsData;
