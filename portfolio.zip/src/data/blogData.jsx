import Img1 from "../assets/imgs/3-2.jpg";
import Img2 from "../assets/imgs/2-2.jpg";
import Img3 from "../assets/imgs/1-2.jpg";


const BlogData = [
  {
    img: Img1,
    smallHeading: "system-adminstration",
    Heading:"How to make a website using WordPress",
  },
  {
    img: Img2,
    smallHeading: "business-management",
    Heading:"Building brands through customer service",
  },
  {
    img: Img3,
    smallHeading: "business-management",
    Heading:"Digital experts get multiple job offers",
  },
 


];

export default BlogData;
