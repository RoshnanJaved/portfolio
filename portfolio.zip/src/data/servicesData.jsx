import Img1 from "../assets/svgs/svgexport-8.svg";
import Img2 from "../assets/svgs/svgexport-9.svg";
import Img3 from "../assets/svgs/svgexport-10.svg";
import Img4 from "../assets/svgs/svgexport-11.svg";


const ServiesData = [
  {
    img: Img1,
    heading: "Creative Design",
    price:"$99",
    para:"Web design refers to the design of websites that are displayed on the internet. It usually refers to the user experience aspects of website development"
  },
  {
    img: Img2,
    heading: "Creative Design",
    price:"$199",
    para:"Web design refers to the design of websites that are displayed on the internet. It usually refers to the user experience aspects of website development"
  },
  {
    img: Img3,
    heading: "Creative Design",
    price:"$299",
    para:"Web design refers to the design of websites that are displayed on the internet. It usually refers to the user experience aspects of website development"
  },
  {
    img: Img4,
    heading: "Creative Design",
    price:"$399",
    para:"Web design refers to the design of websites that are displayed on the internet. It usually refers to the user experience aspects of website development"
  },


];

export default ServiesData;
