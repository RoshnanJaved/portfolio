import Img1 from "../assets/imgs/projectImgs/1-3.jpg";
import Img2 from "../assets/imgs/projectImgs/2-3.jpg"
import Img3 from "../assets/imgs/projectImgs/3-3.jpg"
import Img4 from "../assets/imgs/projectImgs/5-1.jpg"
import Img5 from "../assets/imgs/projectImgs/6-1.jpg"

const Data = [
  {
    id: "Detail",
    img: Img1,
    link: "this da link",
  },
  {
    id: "Detail",
    img: Img5,
    link: "this da link",
  },
  {
    id: "Detail",
    img: Img2,
    link: "this da link",
  },
  {
    id: " Popup",
    img: Img3,
    link: "this da link",
  },
  {
    id: "Vimeo",
    img: Img2,
    link: "this da link",
  },
  {
    id: "Youtube",
    img: Img4,
    link: "this da link",
  },

];

export default Data;
